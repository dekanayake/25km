

module.exports.nearByPlaces = async (event) => {
  const params = JSON.parse(event.body);
  geomatry = params.geometry

  const MongoClient = require('mongodb').MongoClient;
  const uri = "mongodb+srv://places_access:OLKYNwfmLNfp8PGN@cluster0.rkh9q.mongodb.net/melbourne_cbd_places?retryWrites=true&w=majority";
  const client = new MongoClient(uri, { useNewUrlParser: true });
  let result
  client.connect(err => {
    const collection = client.db("melbourne_cbd_places").collection("places");
    collection.find(
      { 'address.coord':
        { $geoWithin:
        { $geometry: geomatry
          }
        }
      }
    ).toArray(function(err, docs) {
      assert.equal(err, null);
      console.log("Found the following records");
      console.log(docs);
      result = docs
    });      
    client.close();
  });

  return {
    statusCode: 200,
    body: result,
    headers: {
      'Access-Control-Allow-Origin': '*',
    },
  };
};
